## Names

1: Wait, doesn't basically every group call themselves "The Foundational People"?

0: I don't think so. What do you mean?

1: I don't want to derail the book. I'll explain in [[var/trash/lost+found/init/names]].

## Numbers

0: Wow, I learned something new today. Anyways, where were we?

1: You said we're...

0: The Foundational People. Exactly.

1: So I said "Wait, doesn't basically every group call themselves The Foundational People"?

0: Well apparently so. But I didn't mean it like that.

1: Like what?

0: I didn't mean we're "The Foundational People" as in "The best people." I meant our people trace our ancestry back to, well, the Foundations.

1: I'm gonna need an explanation of why this is different from the tribe thing.

0: I don't want to derail the book. I'll explain in [[var/trash/lost+found/init/numbers]].

## The beginning

1: Ow, f\*ck sh\*t g\*d d\*mn I think I pulled a muscle that time. You need to warn me before this pop b\*\*eshit zero, it's jarring to get verbally yanked into another universe all the time so unless I get a day off to rest after all this you need to give a bit a heads up when we---

0: Sorry I wasn't listening. That was a lot of stars though so thanks for the words, I'm sure whatever it was was good.

1: Why are you like this?

0: Ok! So last we left off, mathematics was sinking. Something had to be done, and quick.

1: _(Reluctantly)_ What's the problem? These infinite numbers don't seem like that big of a deal. I mean sure they're weird, but infinity doesn't seem that scary to me, like how is this a threat to calculus or geometry exactly?

0: Because of what happened next.

1: What happened next?

0: The beginning.

1: The beginning of what?

0: Of the story of our People.

1: WE HAVEN'T EVEN GOT TO THE BEGINNING YET?!

0: Not quite. Head over to this file with me.

1: I can't believe we're not even---

0: Stop whining and get in. Things are about to get good.

goto: [[var/trash/lost+found/init/beginning]]

## And he called

1: Who?

0: Everyone.

1: What?

0: And he called everyone, keep up.

1: I'm feeling sick from all this context switching. 

0: What context switching? It's all one story. C'mon.

call: [[var/trash/lost+found/init/and-he-called]]

## The second law

0: Hey! I didn't know you knew assembly.

1: Figured I owed you a surprise after the last couple.

0: Y'know that'll help when we get to formal arithmetic. It's pretty low level too. Even lower than assembly.

1: I think I can handle arithmetic.

0: Speaking of which, is `pop rip` even valid assembly? It's been a while.

1: It's valid pseudo-code. Plus it seemed to do what I expected.

0: You know more than I give you credit for sometimes.

1: How else do you think I got accepted to work with you?

0: Who do you think accepted you? You still have a lot to learn.

1: Look I didn't realize we'd be talking about math or whatever but---

0: I think we're past the math for good now.

1: I don't believe you.

0: Ok there's a bit more, but it'll start feeling more like computing from here on.

1: Promise?

0: Promise. Then we'll do so much computing you'll get sick of that too.

1: One can only hope.

0: Good one.

1: That wasn't supposed to be a pun.

0: Well it was. Semantics is tricky.

1: How so?

0: Follow me.

call: [[var/trash/lost+found/init/the-second-law]]
