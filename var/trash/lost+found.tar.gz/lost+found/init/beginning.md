
0: In the beginning, everyone suddenly realized they might be wrong. About everything.

1: Wait you didn't explain why they're worried yet. What happened after Cantor that made mathematicians start to worry?

0: Well we brushed up against it in [[var/trash/lost+found/init/numbers|/opt/numbers]]. Remember that quote that went like this?

> In 1911... Cantor attended \[a thing\], hoping to meet \[some guy\], whose newly published \[book that everyone cites but no one actually reads\] repeatedly cited Cantor's work, but the encounter did not come about.
> 
> -The Dynamic Read-Writable Free Encyclopedic Repository of the Modern State of Human Knowledge

1: Yeah you said to remember his name but I forgot. Who's \[some guy\]?

0: He's the guy who segfaulted mathematics.

1: Segfaulted mathematics?!

0: Ok well not quite. More like he got root on the universe.

1: _Got ROOT on the UNIVERSE?!_

0: Ok that's not quite right either. His name was Bertrand Russell.

1: I think I've heard of him before. What did he do?

0: Well using Cantor's style of set theory, he discovered something called "Russell's Paradox."

1: Ok I've definitely heard of Russell's Paradox before. Remind me of what it is?

0: No.

1: What do you mean "No"?

0: Russell's paradox is one of those things like Gödel and incompleteness. Every damn boring uncreative book under the sun feels the need to talk about these things for some reason. It's tiresome.

1: Aren't you sort of... contributing to that?

0: Yes. Which is why I won't tell you what Russell's Paradox is. Go look it up. We're not in that kind of book.

1: I'm not convinced.

0: The point is that this guy named Bert (who Georg wanted to meet but didn't) found a security vulnerability in standard mathematical reasoning.

1: What was the vulnerability?

0: It boils down to the idea that if you can define a thing then it exists.

1: That's insane. Why would anyone believe that if they can define something that means it exists?

0: It's standard mathematical practice.

1: WHAT?!

0: They call it "Comprehension."

1: The more you talk about mathematics the more suspicious I am of it.

0: Well good, but my point here isn't to criticize the field. It's dishonorable to kick a field while it's down. And if there was ever a time when mathematics was "down," it's when Russell found his paradox and mathematicians started worrying they might have to abandon comprehension. Comprehension is their bread and butter.

1: What's comprehension?

0: It's the logos principle. In the beginning was the word. "Let there be." "Let M be a manifold." "Let S be the set of all sets that don't contain themselves." Every mathematician believes that words are what creates things. At least mathematical things. In fact the idea that for something to exist you have to "construct" it is widely regarded with suspicion in standard mathematics. There's a whole group called the "constructivists" that's entirely defined by the fact that they're weirdos who believe \[that\].

1: Ok you always give these analogies. I'm a developer remember? I'm not afraid of the technical explanation. Give me more details. Be technical. I don't actually believe mathematicians were running around saying "If you can define it, then it exists." There's no way. That's not how they talk.

0: You're right. They don't tend to use those words. But that's what comprehension is. Usually when it happens, it sounds more like this:

_Let S be a set such that:_

or

_Consider the following set:_

$$S = \{ \; x \; | \; p(x) \; \}$$

where $p(x)$ is some propositional function of $x$.

1: What's a propositional function?

0: A sentence with a free variable. Or if you prefer, a function that takes whatever type of thing $x$ is as input, and spits out a sentence as output.

1: Like an English sentence?

0: No, a "proposition." But a proposition is just a fancy word for a sentence in a formal language. Though we're not doing formal set theory here, so it's basically just a sentence in "natural language with math symbols." That's sort of the language that got mathematics in trouble with the paradox.

1: Can you give me an example? Like what does this comprehension thing look like in practice. I want to see if I can tell what the problem is.

0: Sure, here's a comprehension. I could say:

_Let S be the set:_

$$S = \{ \; x \; | \; x \notin \; x \}$$
1: What does that mean?

0: In math speak, $a \in b$ means $a$ is a member of $b$. So whenever you see the $\in$ symbol, the thing on the right is a set, and the thing on the left may or may not be a set too, but it usually is.

1: Which part of this is "comprehension"?

0: The whole thing. Comprehension is the idea that we're allowed to just say stuff like this in the first place. The idea that because we can describe $S$, we're allowed to act as if it exists. That's what got mathematics into trouble with Russell's paradox.

1: How is this any different from programming? We're allowed to define whatever we want in programming too right?

0: Absolutely not! This couldn't be more different from what we do in programming. In programming, we have to earn our variables. We earn every one through our blood, sweat, and tears. If we want to have a variable that represents a set of things with some property, we actually have to _create_ each of those things! Or use someone else's code that creates them for us. Plus we have to find room to store all the things. Plus room to store the set. And if we want our sets to be unordered like they are in mathematics, we have to implement _that_ too, because most ways of storing things in one-dimension (whether books in a library, sentences in a book, or objects in a computer's memory) come with a built-in ordering that we may or may not want. It's not as straightforward as it is in math, we can't just speak things into existence with words like some kind of biblical god.

1: Ok ok I hear you, but how is the comprehension anove any different from this python code:

```python
s = [list for list in lists if list not in list]
```

0: Well before you can run that code, you have to create the "lists" list.

1: Yeah good point. Plus I guess the condition is trivial. Or impossible. You know what I mean.

0: I most certainly don't.

1: I mean obviously a list can't contain itself. That's like, infinite recursion or whatever.

0: Nonsense.

1: What?

0: Lord help me, we have so much work to do. Once we're done with history I'm teaching you programming.

1: You know I'm a professional devel---

0: Well then we'll have to find some way of making you a bit less professional!

1: Can you just explain instead of insulting me?

0:

![[list-contains-itself-in-python.png]]

1: Weird... Ok I guess a list can contain itself in python. How do they implem---

0: Pointers.

1: Obviously. Wow I feel dumb now.

0: Anyways it turns out in mathematics that causes a LOT of problems. Like a historically relevant amount of problems. Those few lines of code were what Russell's Paradox was about. Data structures that contain themselves. In programming it's no big deal. But it sort of broke mathematics.

1: How did it break mathematics?

0: Led to a contradiction. Mathematics can't handle contradictions. Turns out that's another thing we can handle much better than they can. In mathematics, one contradiction anywhere in the system blows everything up. It's a side-effect of some legacy code called The Principle of Explosion that they still haven't fixed in their underlying logic.

1: How can---

0: Now now, let's get back to Russell, we've got a story to tell.

1: Ok where were we?

0: Last we left off, we were somewhere around the beginning.

1: Are we actually there yet?

0: Not quite. But in the beginning, everyone suddenly realized they might be wrong. About everything. Partly due to the set theory Cantor developed, Russell found a critical bug in the supposedly "stable" branch of acceptable mathematical reasoning. And every bit of math in the world was running that code. So it was a serious problem for mathematics.

1: How did they fix the bug?

0: Well it wasn't a simple fix. Comprehension was in everything. Can't just rip that code out or all the textbooks would stop working. Now back then, when you need all the mathematicians in the world to focus on a problem, there was only one guy you could call.

1: Who did they cal---

0: David Hilbert, pop the stack.

1: Wai---

goto: [[lost+found/We#And he called|We]]