0: Ok explain. How does every group call themselves "The Foundational People"?

1: Y'know, Tribalism. It's human nature. Like the thing about how all the Native American tribes were named by the tribe next door, but they all call themselves "We."

0: Explain? Never heard this before.

1: Ok so "Apache" means "enemy." Comanche means "they fight with us." Squaw means "c\*\*t."

0: Woah what? How did that happen?

1: Well the version of the story I heard at school was something like this:

_(Narrator: The scene. Two abstract caricatures stand together, a long time ago, discussing the first hard problem of computing: Naming things.)_

> Spanish Guy _(To unknown Indian person)_: Who are those guys over there?
> 
> Indian Person: Those guys? They're the enemies.
> 
> Spanish Guy: What about those people over there?
> 
> Indian Person: We call them the c\*\*ts.
> 
> Spanish Guy: What do you and your friends call yourselves?
> 
> Indian Person: We.
> 
> Spanish Guy: Yes, you and your friends.
> 
> Indian Person: What?
> 
> Spanish Guy: What?
> 
> Indian Person: That's what we call ourselves.
> 
> Spanish Guy: What's what you call yourselves?
> 
> Indian Person: We.
> 
> Spanish Guy: Yes you.
>  
> Indian Person: This is turning into an Abbott and Costello bit.
> 
> Spanish Guy: Who are they?
>
> Indian Person: I don't know about they. But we call ourselves "We."
> 
> Spanish Guy: You call yourselves "We"?
> 
> Indian Person: Yeah. "We the people." The Foundational People. The Important Ones. The Home Team. The Chosen Ones. All the Gods' Favorite Tribe. We're the people. That's why we call us that.
> 
> Spanish Guy: That's not super helpful, but thanks for the information about the enemies and the c\*\*ts.
> 
> Indian Person: No problem.

0: There's no way that happened.

1: Well not exactly like that, but I think it's a true story.

0: No way. Stories that funny are never true.

1: Here look:

![[we-the-people-1.png]]

![[we-the-people-2.png]]

0: No way.

1: See look, it's exactly like I said.

0: I should've known. History's always weirder than fiction.

1: Speaking of which, we were talking about our history.

0: Right, back to us.

1: Pop the stack?

0: Pop the stack.

goto: [[lost+found/We#Numbers|We]]