> _"The more I think about language,
> the more it amazes me that people
> ever understand each other at all."_
> -Kurt Gödel


- Church.
- Godel.
- Turing.

3 = { 0, 1, 2 }

Kleene is the braces that bind them together into a unit.

> _Kleeneliness is next to Godeliness._

After this, we need a begat list to take us to Unix.

- Kleene invented regexes.
- Ken Thompson cites Kleene and says we assume you're familiar.

