![[computability-turing-godel-church-00.jpg]]


![[computability-turing-godel-church-12.jpg]]


![[computability-turing-godel-church-13.jpg]]


![[computability-turing-godel-church-14.jpg]]


![[computability-turing-godel-church-15.jpg]]