Woe the fall from [Grace](https://en.wikipedia.org/wiki/Grace_Hopper),

Every rising star must [fall](https://dl.acm.org/doi/pdf/10.1145/800025.1198341),

For she who wrote [A-0](https://en.wikipedia.org/wiki/A-0_System),

Also gave the world [COBOL](https://en.wikipedia.org/wiki/COBOL).