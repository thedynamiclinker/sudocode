_A Love Poem to the Lean Agile Enterprise™_

---

## Act I

- Love code.
- Get job.
- Go to job.
- Stand-up meeting: Say what you're gonna do.
- Checkout meeting: Say what you're gonna did.
- Sprint Planning: Say what we're gonna do.
- Retro: Say what we're gonna did.
- Sprint review: Say what we really did.
- Jira: Say what you're gonna do.
- RFC: Say what you're gonna do.
- Code: Do it.
- Tests: Check if you did it.
- CI: Check if you did it remotely.
- PR: Ask permission to have did it.

---

## Act II

- Quit job.
- Start company.

---

## Act III

- Code: Do it.
- Tests: Check if we did it.
- PR: Realize your code belongs in friend's codebase. Send code. Get hi-five.
- Love code again.