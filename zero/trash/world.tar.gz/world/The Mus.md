Descendants of Turing.

Computing as engineering.

The half of early computing that split to build to von Neumann architecture.

The Turtles / The Goerings / The Godels / The Turings.

Down to earth, pragmatic.

Ancestors of C, Python, almost everything.

Char: μ
Character: 無

## Releated /devs

- Most of them.

## Related /etc/groups

- The industry: The companys that take the place of academia in the diaspora period.
- Babel: The distributed bazaar. The diaspora.
- The stars.

## Related topics

- Unix, C, standard computing.
- These guys were orders of magnitude more important from immediately after Church Turing to very recently when things started to switch under the burden of massive modern complexity.