The language of the gods.

The total integration of logic and vibes.
Computation 1 plus Computation 2.
No actual members of this culture are known.

Nevertheless, their writing is easily identifiable,
and has been appearing in recent years at an
accelerating rate, always without attribution.

It is not known if this is an actual group
or what the fuck they're on about.

## World

Char: Ξ
Character: 三
Spelled "Xi".
Pronounced "She".

On the Lamb (kernel space) is written in Xi.
Among themselves, they call it 曰 (pronounced "You").

## Motto

1
κ
λ
μ
ν
Ξ
0

---

## Known Inscriptions

> _Xi is XI is 11 is 3 is Ξ is 三_ 
>        and
> _is is = and and = & & or = ||_
> 	  &θai氣iv 
>   _Xi=11||Ξ=三&c_
