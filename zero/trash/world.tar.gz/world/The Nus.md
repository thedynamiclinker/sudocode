> _Have you heard the good news?_
> -An absolute fanatic.

The Nu Testament.
It's all the rage right now.
Government considering regulating it.
Analogue of the fish people in 33AD Rome.
Early Apocryphal Gospel stuff relevant here.

This is where @2 is from.

Char: ν
Character: 女
