> A novice is easily spotted, because they do too much.
> -Jack Butcher, Visualize Value.

![[a-novice-is-easily-spotted-because-they-do-too-much.jpg|500]]

> In order to do more, you must have the courage to do less.
> -Noboilerplate.

Height is Gaussian.

Wealth is Pareto.

Dice are Gaussian.

Fame is Pareto.
