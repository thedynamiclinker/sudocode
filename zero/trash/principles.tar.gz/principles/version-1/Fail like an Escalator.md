Type: [[Principle]], [[For]], [[Success]], [[During]], [[Failure]]

- Build large systems such that failures of parts doesn't break the whole.
- When parts fail, aim for a working system with fewer features.