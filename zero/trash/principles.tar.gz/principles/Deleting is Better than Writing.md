Or: Deleting Code is better than Writing Code.
Or: Refactor Code Often To Keep it Simple.
Or: Write Fewer Lines that Say the Same Thing.
Or: Imagine Each Word Costs a Dollar.

See: [[Simplicity is the Ultimate Sophistication]]
See: [[Code is a Liability not an Asset]]
See: [[var/trash/principles-v2/Reading is harder than Writing]]