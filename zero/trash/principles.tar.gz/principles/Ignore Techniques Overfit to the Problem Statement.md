Or: The fine line between domain general and domain specific approaches.
Or: Why problem solving is the opposite of system building.
Or: Why leetcode is the opposite of software development.
Or: Why mathematics education is the opposite of mathematics.

---

Unlike homework problems, real world problems have flexible problem statements.

Simpler solutions are often best in real life because they automatically avoid overfitting to the artificially precise problem statements we grow accustomed to in artificial situations like homework, leetcode, and "olympiads" of all forms.

In practice, [[var/trash/principles-v2/Worse is Better]].