Or: Say Hello Again World
Or: Write The Missing Half of Hello World.

---

- We forgot half of `hello world`.
- The second half is making each `hello world` installable, importable, re-usable.
- This requires learning about your language's search paths and install paths.
- This is the first step in [[var/trash/principles-v2/Optimize for Sharing]].
