Or: First Finish, Then Improve
Or: First Finish It, Then Improve It

---

You want to plan 100 steps.
## How to finish last

0. Start
1. Improve 
2. Improve 
    ...
99. Improve 
100. Finish

## How to finish first
0. Start
1. Finish
2. Improve
3. Improve
    ...
100. Improve

Large systems that work come from small systems that work.

Don't scale first.

Finish first.

Before anything else.

Then scale.