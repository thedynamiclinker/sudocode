See: [[Write Executable Documentation]]
See: [[var/trash/principles-v2/Reading is harder than Writing]]