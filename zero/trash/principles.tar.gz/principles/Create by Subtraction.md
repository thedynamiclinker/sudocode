Start with a large system, and delete everything but the best parts.

- Deleting all but the best of Multics gave Unix.
- Deleting all but the best of Minix gave Linux.
- Deleting all but the best of ABC gave Python.

Create the best by deleting the rest.
