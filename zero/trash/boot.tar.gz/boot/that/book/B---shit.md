1: What on earth was that?

0: That was some \*shit.

1: What were we doing before that? I completely forgot.

0: Before we got to `/boot`, I was about to explain what we're _not_ doing here.

1: What we're not doing where?

0: In the book. But then we ended up there.

1: Where?

0: There in this. Over there in `/boot/this`. That part there in `this` was supposed about the things we won't be doing in this book. But it wasn't. That was this. This on the other hand, is that. This part of the book in `/boot/that` is actually about the things we won't be doing in this book.

1: This is the opposite of helpful.

0: Ok let's start over.

1: Where do we start?

0: In the beginning.

1: Seems like a good place to sta---

0: What's a bible?

1: Something you won't stop talking about.

(continue with r.e.f., poc||gtfo, &c.)