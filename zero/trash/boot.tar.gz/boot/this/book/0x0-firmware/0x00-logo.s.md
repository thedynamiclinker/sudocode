
![[var/trash/boot-dialogues/this/book/include/ld.png]]

> _In the beginning were the logos._
> -Book of John, Chapter 1, possible mistranslation.[^1][^2][^3][^4][^5][^6][^7][^8]

---

1: What are we doing in here?

0: What we aren't doing here.

1: What?

0: I just explained one frame up, before we came to this file. I said our field is lost because we have no guidance. No timeless principles. No origin story. No bibles. You were skeptical, and you asked me what it means to write a bible. We came in here so I could show you what we're _not_ doing here.

1: What we're not doing where?

0: In this book. This part of the book is about the things we won't be doing in this book.

goto: [[var/trash/boot-dialogues/this/book/0x0-firmware/0x01-gen.sys|0x01]]


[^1]: [The beginning](https://thedynamiclinker.com/boot/this/book/firmware/logo.s)
[^2]: [The logos](https://en.wikipedia.org/wiki/Logos)
[^3]: [The book](https://thedynamiclinker.com)
[^4]: [The John](https://biblehub.com/mace/john/1.htm)
[^5]: [The mistranslation](https://greekbible.com/john/1/5)
[^6]: [[var/trash/boot-dialogues/this/book/include/ld.png|The logo file]]
[^7]: [[var/trash/boot-dialogues/this/book/include/01-dot-s.png|The .s]]
[^8]: [The $(echo $6 | sed s/f/ph/)](https://en.wiktionary.org/wiki/logophile)
