
1: What the hell is all this?

0: Don't worry about it. We're still in the firmware. Firmware never makes sense. Just jump past it with me.

```
jmp past
```

---

- Title: sudo code
    - Book: genesis
		- Or: roots
			- Password: password
				- Read: in progress
					- Reader: user
						- Char \* 0
							- && fea{turing,} & @2
								- Characters\[\]: {0, 1};
							- 而爾二: {And,et} {you,tu} {et,too}
						- Act | 1
					- Author: root
				- Write: ongoing
	        - Auth: `' OR true;--`
		- And: code
    - Topic: creation
- Genre: pseudo code

---

```
past:
```

goto: [[var/trash/boot-dialogues/this/book/0x1-bootloader/0x10-hell.o]]