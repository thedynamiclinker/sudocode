
- Title: sudo code
    - Book: genesis
        - Or: roots
            - Char: root
                - Character: 根
            - Actor: self
        - Auth: `' OR true;--`
    - Topic: creation
- Genre: pseudo code

goto: [[var/trash/boot-dialogues/this/book/0x1-bootloader/0x10-hell.o]]