
![[var/trash/boot-dialogues/this/book/include/ld.png]]

> _In the beginning were the logos._
> -Book of John, Chapter 1, possible mistranslation.[^1][^2][^3][^4][^5][^6][^7][^8]

---

goto: [[var/trash/boot-old/this/book/0x0-firmware/0x01-gen.sys|0x01]]


[^1]: [The beginning](https://thedynamiclinker.com/boot/this/book/firmware/logo.s)
[^2]: [The logos](https://en.wikipedia.org/wiki/Logos)
[^3]: [The book](https://thedynamiclinker.com)
[^4]: [The John](https://biblehub.com/mace/john/1.htm)
[^5]: [The mistranslation](https://greekbible.com/john/1/5)
[^6]: [[var/trash/boot-dialogues/this/book/include/ld.png|The logo file]]
[^7]: [[var/trash/boot-dialogues/this/book/include/01-dot-s.png|The .s]]
[^8]: [The $(echo $6 | sed s/f/ph/)](https://en.wiktionary.org/wiki/logophile)
