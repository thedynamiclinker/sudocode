![[var/trash/boot-dialogues/this/book/include/ld-man-page.png]]

根. (noun).
1. root
2. radical
3. genesis
4. foundations
5. a unicode character, pronounced in modern mandarin as [gen](https://en.wiktionary.org/wiki/%E6%A0%B9), and in the oldest known versions of the language as [ken](https://doc.cat-v.org/bell_labs/utf-8_history).

goto: [[var/trash/boot-dialogues/this/book/0x2-kernel/0x20-initrd]]
