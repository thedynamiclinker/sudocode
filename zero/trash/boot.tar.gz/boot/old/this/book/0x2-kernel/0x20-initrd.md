> _Trees are the roots of the underground._
> -Hello Corporation©®™, internal documents.[^1]

goto: [[var/trash/boot-old/this/book/0x2-kernel/0x21-bzImage]]

[^1]: Hello Corporation is a subsidiary of the [Root enterprise](https://github.com/enterprises/root).
