```
           @(意) == 意
           |
         @(意) == 音
         |
       @(音) == /ɚ/
       | |
       | @(意) == sound
       |   |
       |   @(意) == meaning
       |     |
       |\    @(音) == 一
       | \
       |  \
       二  \
There are 二h二d problems in creation:
0. cache invalidation,
1. naming things,
2. off by 一二||s.
```

[[0x30-ld.so]]