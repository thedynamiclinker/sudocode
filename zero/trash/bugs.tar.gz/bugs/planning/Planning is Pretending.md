In creative fields, the act of planning involves pretending to build something rather than actually building something. Planning in these fields thus suffers from the limitations of imagination, including all software bugs related to the difference between natural language descriptions and hands-on experiences.

