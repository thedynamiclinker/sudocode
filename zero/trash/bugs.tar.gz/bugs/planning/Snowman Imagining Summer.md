Type: [[Wrong]], [[Prediction]], [[From]], [[Feeling]]

- A software vulnerability in the human mind arising from the tendency to conflate a thing with its description.
- When `thing.description` makes us feel good, so we imagine our life will be better if it involves more `thing`.

From the movie *Frozen*.