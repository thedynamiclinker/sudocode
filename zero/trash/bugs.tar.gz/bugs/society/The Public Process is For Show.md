Examples: Hiring someone unofficially and then making them apply through the official channels as a formality.

Reversals: Open source.

This principle needs a better name.