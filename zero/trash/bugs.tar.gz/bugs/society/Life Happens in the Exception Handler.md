
The observation that a large amount of society works not because of the officially documented processes work, but because the methods for handling failure are less formal, more human, and thus more robust.

Related:
- [[Fragile Modularity]]
- [[Overfitting to Perfection]]
- [[Human Nature as Process]]