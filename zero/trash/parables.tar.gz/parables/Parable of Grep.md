Type: [[Reusable]], [[System]], [[Creation]], [[Parable]]

---

IN PROGRESS

 - We don't remember the `qed` editor, but everyone knows `grep`.
- And `grep` was implemented by ripping out a small part of `qed`.
- The command was originally called `s`, for "search."
- Became grep when it ken moved it out of his home directory and into `/bin`.
- The word grep was in the Oxford English Dictionary by the following year.