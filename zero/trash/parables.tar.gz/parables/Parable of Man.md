Type: [[Learnable]], [[System]], [[Creation]], [[Parable]]

IN PROGRESS
Sources:
- https://manpages.bsd.lv/history.html

---

![[unix-programmers-manual-v1.jpg]]

