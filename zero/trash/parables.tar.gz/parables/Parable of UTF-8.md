Type: [[Fast]], [[System]], [[Creation]], [[Parable]]

---

Looking around at some UTF-8 background,
	I see the same incorrect story being repeated over and over.

The incorrect version is:
1. IBM designed UTF-8.
2. Plan 9 implemented it.

That's not true.

UTF-8 was designed,
in front of my eyes \[by Ken Thompson\],
on a placemat in a New Jersey diner
one night in September or so 1992.

...

The next day all the code was done
and we started converting the text
files on the system itself.

By Friday some time Plan 9 was running,
and only running,
what would be called UTF-8.

-Rob Pike[.](https://doc.cat-v.org/bell_labs/utf-8_history)